import React, { Component } from 'react';
import axios from 'axios';
import Filters from '../Component/Filters/Filter';
import './Home.css';

const API_URL = 'https://rickandmortyapi.com/api/character/';
class Home extends Component {

  constructor(){
    super();
    this.state = {
      users: [],
      search: ''
    }
  }

  handleChange = (e) => {
    this.setState({
        [e.target.name]: e.target.value
    })
}

onSubmit = (e) => {
   e.preventDefault();
        const fileredItems = this.state.users.filter((item) => item.name.toLowerCase().includes(this.state.search.toLowerCase()));
        this.setState({
          users: fileredItems
        })
}


  componentDidMount() {
    const url = `${API_URL}`;
    axios.get(url).then(response => response.data)
    .then((data) => {
      this.setState({ users: data.results })
     })
  }

  render() {

    const userDesign = this.state.users.map((user) => (
      <div className="col-sm-3">
      <article key={user.id} className="characterCard">
        <div data="card header" className="characterCard__Img">
          <div className="card-image">
            <img className="img img-responsive" src={user.image} alt={user.name}/>
          </div>
              <div className="characterCard__Title">
                <h2 className="characterCard__Name">{user.name}</h2>
              </div>
            </div>
            <div data="card info" className="characterCard__Info">
              <div className="characterCard__Text">
                <span>STATUS</span>
                <p>{user.status}</p>
              </div>
              <div className="characterCard__Text">
                <span>SPECIES</span>
                <p>{user.species}</p>
              </div>
              <div className="characterCard__Text">
                <span>GENDER</span>
                <p>{user.gender}</p>
              </div>
              <div className="characterCard__Text">
                <span>ORIGIN</span>
                <p>{user.origin.name}</p>
              </div>
              <div className="characterCard__Text">
                <span>LAST LOCATION</span>
                <p>{user.location.name}</p>
              </div>
          
          </div>
          </article>
        </div>
    ));
    return (
      <div className="container">
        <div className="row">
            <Filters />
        <div className="col-sm-9 col-md-9 col-lg-9 full-height">
          <div className="searchFilter">
          <form>
                <label>
                    Search By Name: 
                    <input
                        name='search'
                        defaultValue={this.state.search}
                        onChange={e => this.handleChange(e)}/>
                </label>
                <button onClick={(e) => this.onSubmit(e)}>Send</button>         
            </form>
          </div>
          <div className="row">
            {userDesign}
          </div>
        </div>
        </div>
     </div>
    );
  }
  }

export default Home;
