import React from 'react';
import './Filter.css';

function Filters() {
  return (
    <div className="col-sm-3 col-md-3 col-lg-3 full-height">
    <div className="filterCard">
      <h3>Species</h3>
        <div className="custom-control custom-checkbox">
            <input type="checkbox" className="custom-control-input" id="human"/>
            <label className="custom-control-label" htmlFor="defaultUnchecked">Human</label>
        </div>
        <div className="custom-control custom-checkbox">
            <input type="checkbox" className="custom-control-input" id="mytholog"/>
            <label className="custom-control-label" htmlFor="defaultUnchecked">mytholog</label>
        </div>
        <div className="custom-control custom-checkbox">
            <input type="checkbox" className="custom-control-input" id="others"/>
            <label className="custom-control-label" htmlFor="defaultUnchecked">others</label>
        </div>
    </div>
    <div className="filterCard">
      <h3>Gender</h3>
        <div className="custom-control custom-checkbox">
            <input type="checkbox" className="custom-control-input" id="male"/>
            <label className="custom-control-label" htmlFor="defaultUnchecked">Male</label>
        </div>
        <div className="custom-control custom-checkbox">
            <input type="checkbox" className="custom-control-input" id="female"/>
            <label className="custom-control-label" htmlFor="defaultUnchecked">Female</label>
        </div>
    </div>
    <div className="filterCard">
      <h3>Origin</h3>
        <div className="custom-control custom-checkbox">
            <input type="checkbox" className="custom-control-input" id="unknown"/>
            <label className="custom-control-label" htmlFor="defaultUnchecked">Unknown</label>
        </div>
        <div className="custom-control custom-checkbox">
            <input type="checkbox" className="custom-control-input" id="post-apocalyptic-earch"/>
            <label className="custom-control-label" htmlFor="defaultUnchecked">Post Apocalyptic Earch</label>
        </div>
        <div className="custom-control custom-checkbox">
            <input type="checkbox" className="custom-control-input" id="nuptia"/>
            <label className="custom-control-label" htmlFor="defaultUnchecked">Nuptia 4</label>
        </div>
        <div className="custom-control custom-checkbox">
            <input type="checkbox" className="custom-control-input" id="others"/>
            <label className="custom-control-label" htmlFor="defaultUnchecked">Others Origins</label>
        </div>
    </div>
  </div>
  );
}

export default Filters;