import React from 'react';
import Home from './Container/Home';
import './App.css';

function App() {
  return (
    <>
      <Home />
    </>
  );
}

export default App;
